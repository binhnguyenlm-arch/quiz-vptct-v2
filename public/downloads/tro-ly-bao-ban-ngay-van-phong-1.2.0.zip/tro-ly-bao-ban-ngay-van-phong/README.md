# Trợ lý Báo ban ngày Văn phòng — 1.2.0

Mẫu định dạng đang dùng: **MAU-BAO-BAN-CHUAN.docx** do chủ plugin chỉnh ngày 29/9/2026. Bộ xuất giữ định dạng run và bảng của tệp này, không áp cỡ chữ hoặc đậm/nghiêng đồng loạt. Các giá trị minh họa không được dùng làm dữ liệu báo cáo.

## Hướng dẫn nhanh
Dùng Work ngay từ đầu. Gửi văn bản hoặc ảnh theo khâu/cảng trợ lý đang hỏi. Ảnh kèm một số không có nhãn: số đó là tồn bãi thực tế (TEU) của cảng đang xử lý. Ảnh Cát Lái tự cập nhật sản lượng giao nhận đường bộ và thời gian giao nhận bình quân; chỉ hỏi nếu thiếu hoặc không đọc rõ.

Lời nhắc duy nhất: **Bắt đầu lập báo ban ngày Văn phòng**.

## Dùng Work ngay từ đầu
1. Mở Work (Làm việc), chọn **Trợ lý Báo ban ngày Văn phòng**.
2. Gửi **Bắt đầu lập báo ban ngày Văn phòng**.
3. Trợ lý kiểm tra bộ xuất Word một lần trước khi hỏi dữ liệu. Nếu phiên chưa có công cụ chạy chương trình, trợ lý báo ngay để tránh nhập xong mới phải chuyển.
4. Nhập dữ liệu từng khâu như bình thường. Không cần cài thư viện, gõ lệnh hoặc điền biểu mẫu kỹ thuật.
5. Đủ dữ liệu, trợ lý dùng bộ xuất có sẵn để tạo DOCX. Dữ liệu được lưu theo tiến độ để sửa hoặc tiếp tục mà không nhập lại.

Có thể dùng phiên Codex có Python và công cụ tạo tệp. Plugin không tự bật Work hoặc cấp quyền chạy cho Chat thông thường.
## Nội dung gói
Mẫu DOCX gốc thực tế; cấu hình; 3 ảnh định dạng; bộ xuất Python 3 không phụ thuộc thư viện ngoài; hướng dẫn trường dữ liệu. Không có API, website hay ứng dụng ngoài.
Tiêu đề 14; lịch trực 13, nhãn đậm/tên thường theo ảnh cuối. TCHP có mẫu nhập 5 trường. Đủ 7 cảng thì dùng lại hoạt động Cát Lái và chuyển kế hoạch, ghi chú, lịch trực.
## Kiểm chứng và giới hạn
Bộ xuất đã được kiểm tra dữ liệu thiếu, ngày 01, làm tròn, bình quân, tồn, chữ đậm/cỡ chữ, ô gộp, số mẫu cũ và bảo toàn các phần khác của DOCX. Thời gian chạy bộ điền mẫu trên bộ dữ liệu thử tại máy xây dựng khoảng 0,03 giây; không bao gồm đọc ảnh, suy luận, giao tiếp hoặc kiểm tra hình thức và không phải cam kết thời gian toàn tác vụ.
Môi trường xây dựng thiếu LibreOffice nên chưa xem được ảnh render của bản xuất. Khi dùng ở môi trường có renderer, trợ lý phải kiểm tra hình thức trước khi khẳng định đã kiểm tra. Gói vẫn riêng tư, chưa chia sẻ công khai.




Bản 1.2.0 đã kiểm tra bảo toàn run, bảng trực, chữ ký, cỡ chữ 13 của khối đầu/bảng kế hoạch, ghi chú nghiêng và hoạt động Cát Lái đậm số/đơn vị. Chưa kiểm tra bằng ảnh render vì môi trường xây dựng thiếu LibreOffice. Các mô tả định dạng cũ nếu khác phải nhường cho mẫu chuẩn mới.

