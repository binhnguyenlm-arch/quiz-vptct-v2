#!/usr/bin/env python3
"""Deterministic report writer. Python 3 standard library only; no network."""
import argparse, copy, datetime as dt, hashlib, io, json, re, sys, time, zipfile
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import xml.etree.ElementTree as E

W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS={'w':W}
def q(n): return '{'+W+'}'+n
PORTS={'Cát Lái':138244,'TCIT':45096,'TCTT':20020,'TCHP':9907,'HICT':35310,'TC189':5481,'TC128':10364}
DUTIES=['Trực xe','CTr','Cát Lái','KVMB','Trực TM','Hậu cần','TCHP','TCMT','Nội vụ','CNTT','Cái Mép','TCPC','Trực chỉ huy cơ quan','TTĐĐ','KVTNB','Xử lý sự cố kỹ thuật','Thạnh Mỹ Lợi','ICDST','Trực ban tác chiến','ICDLB']
HASH='4b63a263e36d2a7c1443d2346157a53a0687a82902c05ba22a1f81099121ca9e'
def txt(e): return ''.join(t.text or '' for t in e.iter(q('t')))
def child(e,n):
    v=e.find(q(n))
    if v is None: v=E.SubElement(e,q(n))
    return v
def attr(e,n,**a):
    v=child(e,n)
    for k,x in a.items(): v.set(q(k),str(x))
    return v
def prop(e,n):
    v=e.find(q(n))
    if v is None: v=E.Element(q(n));e.insert(0,v)
    return v
def fmt(r,size=14,bold=None):
    rp=prop(r,'rPr');attr(rp,'rFonts',ascii='Times New Roman',hAnsi='Times New Roman',eastAsia='Times New Roman',cs='Times New Roman')
    attr(rp,'sz',val=size*2);attr(rp,'szCs',val=size*2)
    color=attr(rp,'color',val='000000')
    for k in list(color.attrib):
        if k!=q('val'): del color.attrib[k]
    if bold is not None: attr(rp,'b',val='1' if bold else '0');attr(rp,'bCs',val='1' if bold else '0')
    for tag in ('highlight','shd'):
        for x in list(rp.findall(q(tag))): rp.remove(x)
def run(p,s,b=False,size=14,italic=False,underline=False):
    r=E.SubElement(p,q('r'));fmt(r,size,b)
    if italic: attr(prop(r,'rPr'),'i',val=1)
    if underline: attr(prop(r,'rPr'),'u',val='single')
    chunks=str(s).split('\n')
    for i,c in enumerate(chunks):
        if i: E.SubElement(r,q('br'))
        t=E.SubElement(r,q('t'));t.set('{http://www.w3.org/XML/1998/namespace}space','preserve');t.text=c
def clear(p):
    for c in list(p):
        if c.tag!=q('pPr'): p.remove(c)
def setp(p,s,b=False,size=14,align=None):
    clear(p)
    if align: attr(prop(p,'pPr'),'jc',val=align)
    rich(p,s,size,b)
def rich(p,value,size=14,b=False):
    if isinstance(value,str): run(p,value,b,size)
    else:
        for v in value: run(p,v['text'],v.get('bold',b),size,v.get('italic',False),v.get('underline',False))
def cellp(c):
    p=c.find(q('p'))
    if p is None: p=E.SubElement(c,q('p'))
    for x in list(c):
        if x.tag==q('p') and x is not p: c.remove(x)
    return p
def integer(v): return isinstance(v,int) and not isinstance(v,bool) and v>=0
def number(v):
    if isinstance(v,bool) or not isinstance(v,(str,int,float)): raise ValueError('number')
    z=Decimal(str(v))
    if not z.is_finite() or z<0: raise ValueError('number')
    return z
def rounded(v): return int(v.quantize(Decimal('1'),rounding=ROUND_HALF_UP))
def thousands(v): return format(v,',').replace(',','.')
def dec(v): return format(number(v).normalize(),'f').replace('.',',')
def weekday(d): return ['THỨ HAI','THỨ BA','THỨ TƯ','THỨ NĂM','THỨ SÁU','THỨ BẢY','CHỦ NHẬT'][d.weekday()]
def short(d): return f'{d.day}/{d.month}/{d.year}'
def richvalid(v): return isinstance(v,str) and bool(v.strip()) or isinstance(v,list) and bool(v) and all(isinstance(x,dict) and isinstance(x.get('text'),str) for x in v)
def validate(data):
    errors=[]
    try:
        d=dt.date.fromisoformat(data['report_date'])
        if d.day==1: errors.append('Ngày 01: công cụ không áp dụng.')
    except (ValueError,KeyError,TypeError): errors.append('report_date: cần YYYY-MM-DD');d=None
    for key in ['security','plan','notes','commander','duties','ports','cat_lai_activity']:
        if key not in data: errors.append('Thiếu '+key)
    sec=data.get('security')
    if not isinstance(sec,list) or not all(richvalid(x) for x in sec): errors.append('security: danh sách vụ việc hoặc [] nếu Không')
    for name,cap in PORTS.items():
        p=data.get('ports',{}).get(name,{})
        for key in ['ships','cumulative_teu','stock_teu']:
            if not integer(p.get(key)): errors.append(f'{name}.{key}: thiếu hoặc không phải số nguyên không âm')
        for key in ['ps','barge']:
            if key not in p: errors.append(f'{name}.{key}: thiếu');continue
            try:
                if p[key] not in (None,'-'): number(p[key])
                if p[key] not in (None,'-') and number(p[key])==0:
                    trips=p.get('ships') if key=='ps' else p.get('barge_trips')
                    if trips!=0: errors.append(f'{name}.{key}: NSGP 0 cần số chuyến 0; nếu không hoạt động dùng null')
            except (ValueError,ArithmeticError): errors.append(f'{name}.{key}: cần số thập phân dấu chấm hoặc null')
        if integer(p.get('stock_teu')) and p['stock_teu']>cap and p.get('stock_confirmed') is not True: errors.append(f'{name}: tồn vượt sức chứa cần stock_confirmed=true sau xác nhận')
    a=data.get('cat_lai_activity',{})
    if not integer(a.get('road_teu')): errors.append('Cát Lái: thiếu road_teu')
    try: number(a['hours_per_cont'])
    except (KeyError,ValueError,ArithmeticError): errors.append('Cát Lái: thiếu hours_per_cont hợp lệ')
    commander=data.get('commander',{})
    for k in ['name','title']:
        if not isinstance(commander.get(k),str) or not commander[k].strip(): errors.append('commander.'+k+': thiếu')
    for k in DUTIES:
        if not isinstance(data.get('duties',{}).get(k),str) or not data['duties'][k].strip(): errors.append('Lịch trực: thiếu '+k)
    plan=data.get('plan')
    if plan is not None:
        if not isinstance(plan,list): errors.append('plan: cần danh sách hoặc null nếu Không')
        else:
            for i,row in enumerate(plan):
                if not isinstance(row,list) or len(row)!=5 or not all(isinstance(x,str) or richvalid(x) for x in row): errors.append(f'plan[{i}]: cần đúng 5 ô')
    notes=data.get('notes')
    if notes is not None and (not isinstance(notes,list) or not all(richvalid(n) for n in notes)): errors.append('notes: danh sách hoặc null')
    merges=data.get('plan_merges',[]);occupied=set()
    for m in merges:
        if not isinstance(m,list) or len(m)!=4 or not all(integer(n) for n in m): errors.append('plan_merges: cần [r0,c0,r1,c1]');continue
        r0,c0,r1,c1=m
        if not plan or not(0<=r0<=r1<len(plan) and 0<=c0<=c1<5): errors.append('plan_merges: ngoài bảng');continue
        for r in range(r0,r1+1):
            for c in range(c0,c1+1):
                if (r,c) in occupied: errors.append('plan_merges: chồng ô')
                occupied.add((r,c))
                if (r,c)!=(r0,c0) and plan[r][c] not in ('',[]): errors.append('Ô bị gộp phải trống, chuyển nội dung vào ô đầu')
    return errors
def newstate():
    today=dt.datetime.now(dt.timezone(dt.timedelta(hours=7))).date()
    return {'report_date':today.isoformat(),'security':None,'ports':{n:{} for n in PORTS},'cat_lai_activity':{'road_teu':None,'hours_per_cont':None},'plan':None,'notes':None,'commander':{'name':None,'title':None},'duties':{n:None for n in DUTIES},'completed':[]}
def ready(data):
    errors=validate(data)
    for k in ['security','plan','notes']:
        if k not in data.get('completed',[]): errors.append(k+': chưa xác nhận đã nhận (Không cũng phải đánh dấu completed)')
    return errors
def splice(p,start,end,value):
    """Replace text across split runs while preserving every run property."""
    nodes=list(p.iter(q('t')));pos=0;inserted=False
    for t in nodes:
        s=t.text or '';lo=pos;hi=pos+len(s);pos=hi
        if hi<=start or lo>=end:continue
        left=s[:max(0,start-lo)];right=s[max(0,end-lo):] if end<hi else ''
        t.text=left+(str(value) if not inserted else '')+right
        t.set('{http://www.w3.org/XML/1998/namespace}space','preserve');inserted=True
    if not inserted:raise ValueError('Không tìm được vị trí thay dữ liệu')
def sub(p,pattern,value):
    hits=list(re.finditer(pattern,txt(p)))
    if not hits:raise ValueError('Mẫu thiếu trường: '+pattern)
    for hit in reversed(hits):splice(p,hit.start(),hit.end(),value(hit) if callable(value) else value)
def style_run(p,offset=0):
    pos=0
    for r in p.iter(q('r')):
        s=txt(r)
        if s and pos+len(s)>offset:return copy.deepcopy(r.find(q('rPr')))
        pos+=len(s)
    return None
def addstyled(p,value,rp):
    values=[{'text':value}] if isinstance(value,str) else value
    for v in values:
        r=E.SubElement(p,q('r'))
        if rp is not None:r.append(copy.deepcopy(rp))
        for key,tag in [('bold','b'),('italic','i'),('underline','u')]:
            if key in v:
                val=('single' if v[key] else 'none') if key=='underline' else ('1' if v[key] else '0')
                attr(prop(r,'rPr'),tag,val=val)
                if key in ('bold','italic'):attr(prop(r,'rPr'),tag+'Cs',val=val)
        for i,s in enumerate(v['text'].split('\n')):
            if i:E.SubElement(r,q('br'))
            t=E.SubElement(r,q('t'));t.set('{http://www.w3.org/XML/1998/namespace}space','preserve');t.text=s
def fill(p,value,rp=None):
    if rp is None:rp=style_run(p)
    clear(p);addstyled(p,value,rp)
def growable(table):
    for tr in table.findall(q('tr')):
        pr=prop(tr,'trPr')
        for h in pr.findall(q('trHeight')):
            if h.get(q('hRule'))=='exact':h.set(q('hRule'),'atLeast')
def make_plan(data,reference):
    t=copy.deepcopy(reference);rows=t.findall(q('tr'));prototype=copy.deepcopy(rows[1])
    for row in rows[1:]:t.remove(row)
    made=[]
    for values in data['plan']:
        row=copy.deepcopy(prototype);cells=row.findall(q('tc'))
        for c,value in zip(cells,values):fill(cellp(c),value)
        t.append(row);made.append(cells)
    widths=[int(c.get(q('w'))) for c in t.find(q('tblGrid'))]
    for r0,c0,r1,c1 in data.get('plan_merges',[]):
        for ri in range(r0,r1+1):
            cp=prop(made[ri][c0],'tcPr');attr(cp,'tcW',w=sum(widths[c0:c1+1]),type='dxa')
            if c1>c0:attr(cp,'gridSpan',val=c1-c0+1)
            if r1>r0:attr(cp,'vMerge',val='restart' if ri==r0 else 'continue')
            row=t.findall(q('tr'))[ri+1]
            for ci in range(c0+1,c1+1):row.remove(made[ri][ci])
    growable(t);return t
def write_report(data,target,template):
    errors=ready(data)
    if errors:raise ValueError('\n'.join(errors))
    raw=template.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=HASH:raise ValueError('Mẫu chuẩn không khớp phiên bản hỗ trợ')
    z=zipfile.ZipFile(io.BytesIO(raw));xml=z.read('word/document.xml');nsmap={}
    for _,pair in E.iterparse(io.BytesIO(xml),events=['start-ns']):
        nsmap[pair[0]]=pair[1]
        try:E.register_namespace(*pair)
        except ValueError:pass
    root=E.fromstring(xml);body=root.find('w:body',NS);ps=body.findall('w:p',NS);tables=body.findall('w:tbl',NS)
    if len(tables)!=6 or len(ps)<14 or 'an ninh' not in txt(ps[4]):raise ValueError('Sai cấu trúc mẫu chuẩn')
    d=dt.date.fromisoformat(data['report_date']);prev=d-dt.timedelta(days=1)
    cells=tables[0].findall('w:tr',NS)[2].findall('w:tc',NS)
    sub(cellp(cells[0]),r'\d+/TH-VP',f'{d.day}{d.month}{str(d.year)[2:]}/TH-VP')
    hp=cellp(cells[1]);sub(hp,r'ngày \d+ tháng \d+ năm \d+',f'ngày {d.day} tháng {d.month} năm {d.year}')
    if txt(ps[0]).strip()=='[':body.remove(ps[0])
    sub(ps[1],r'\d+/\d+/\d+',short(d))
    # Replace separate semantic fields to retain italic period and bold heading.
    sub(ps[3],r'(?:THỨ (?:HAI|BA|TƯ|NĂM|SÁU|BẢY)|CHỦ NHẬT)',weekday(prev))
    sub(ps[3],r'\d+/\d+/\d+',short(prev))
    sub(ps[3],r'(?<=từ 06h00 ngày )\d+/\d+',f'{prev.day}/{prev.month}')
    sub(ps[3],r'(?<=– 06h00 ngày )\d+/\d+',f'{d.day}/{d.month}')
    sec=ps[4];old=txt(sec);off=old.index(':')+2;srp=style_run(sec,off)
    if data['security']:
        splice(sec,off,len(old),'');addstyled(sec,data['security'][0],srp);anchor=sec
        for value in data['security'][1:]:
            p=copy.deepcopy(sec);clear(p);addstyled(p,value,srp);body.insert(list(body).index(anchor)+1,p);anchor=p
    # Empty list is explicit no incidents. Retain template's exact no-incident sentence.
    rows=tables[1].findall(q('tr'));label=rows[6].find(q('tc'))
    for vm in label.findall('w:tcPr/w:vMerge',NS):label.find(q('tcPr')).remove(vm)
    fill(cellp(label),'Tỷ lệ tồn bãi (%)');tables[1].remove(rows[7])
    for col,(name,cap) in enumerate(PORTS.items(),1):
        p=data['ports'][name]
        def prod(k):return '-' if p[k] in (None,'-') or number(p[k])==0 else dec(p[k])
        values=[f"{p['ships']:02d}",thousands(p['cumulative_teu']),thousands(rounded(Decimal(p['cumulative_teu'])/prev.day)),prod('ps'),prod('barge'),str(rounded(Decimal(p['stock_teu'])*100/cap))+'%']
        for row,value in zip(rows[1:7],values):
            pcell=cellp(row.findall(q('tc'))[col]);sub(pcell,r'.+',value)
    a=data['cat_lai_activity']
    sub(ps[8],r'[\d.]+(?= Teu)',thousands(a['road_teu']))
    sub(ps[8],r'[\d,]+(?= h/cont)',dec(a['hours_per_cont']))
    for p in (ps[10],ps[12]):
        sub(p,r'\d+/\d+/\d+',short(d));sub(p,r'(?:THỨ (?:HAI|BA|TƯ|NĂM|SÁU|BẢY)|CHỦ NHẬT)',weekday(d))
    cp=ps[13];full=txt(cp);start=full.index('Đ/c ')+4;end=full.index(' –')
    splice(cp,start,end,data['commander']['name']);full=txt(cp);start=full.index('– ')+2
    splice(cp,start,len(full),data['commander']['title'])
    # Use actual five-column plan table, not a newly designed table.
    plan=tables[2];idx=list(body).index(plan)
    if data['plan']:body.insert(idx,make_plan(data,plan));body.remove(plan)
    else:
        for row in plan.findall(q('tr'))[1:]:plan.remove(row)
        # Keep blank frame as requested; no sample schedule remains.
    notes=tables[3]
    if data['notes']:
        c=notes.find('w:tr/w:tc',NS);sample=c.find(q('p'));rp=style_run(sample,2)
        for p in list(c.findall(q('p'))):c.remove(p)
        for value in data['notes']:
            p=copy.deepcopy(sample);clear(p)
            # Base notes style is italic 13; source emphasis passed in rich runs.
            plainrp=style_run(sample, len(txt(sample))-1)
            addstyled(p,value,plainrp);c.append(p)
        growable(notes)
    else:body.remove(ps[11]);body.remove(notes)
    for row in tables[4].findall(q('tr'))[1:]:
        for c in row.findall(q('tc')):
            p=cellp(c);s=txt(p);label=s.split(':')[0].strip()
            name='Luật' if label=='Xử lý giao thông Cát Lái' else data['duties'][label]
            hit=re.search(r'đ/c\s+',s)
            if not hit:raise ValueError('Thiếu nhãn đ/c trong mẫu')
            splice(p,hit.end(),len(s),name)
    for table in (tables[1],tables[4]):growable(table)
    # No global font, bold, italic, alignment, borders, or signature resets.
    target=Path(target)
    if target.resolve()==template.resolve():raise ValueError('Không ghi đè mẫu')
    target.parent.mkdir(parents=True,exist_ok=True)
    part=E.tostring(root,encoding='utf-8',xml_declaration=True)
    for prefix,uri in nsmap.items():
        key=('xmlns:'+prefix if prefix else 'xmlns').encode()
        if key+b'=' not in part:part=part.replace(b'<w:document',b'<w:document '+key+b'="'+uri.encode()+b'"',1)
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as out:
        for item in z.infolist():out.writestr(item,part if item.filename=='word/document.xml' else z.read(item.filename))
    return target

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path);ap.add_argument('--output',type=Path);ap.add_argument('--init',type=Path);ap.add_argument('--check',action='store_true');ap.add_argument('--preflight',action='store_true');args=ap.parse_args()
    template=Path(__file__).resolve().parent.parent/'assets'/'MAU-BAO-BAN-CHUAN.docx'
    if args.preflight:
        if not template.exists() or hashlib.sha256(template.read_bytes()).hexdigest()!=HASH:raise ValueError('Thiếu hoặc sai mẫu Word đóng gói')
        print('READY: Python standard library; DOCX template verified; no installation required.');return
    if args.init:
        if args.init.exists():raise ValueError('Tệp trạng thái đã tồn tại; không ghi đè')
        args.init.parent.mkdir(parents=True,exist_ok=True);args.init.write_text(json.dumps(newstate(),ensure_ascii=False,indent=2),encoding='utf-8');return
    if not args.input:ap.error('--input required')
    data=json.loads(args.input.read_text(encoding='utf-8-sig'));errors=ready(data)
    if errors: print(json.dumps({'ready':False,'missing_or_invalid':errors},ensure_ascii=False));sys.exit(2)
    if args.check:print('{"ready":true}');return
    d=dt.date.fromisoformat(data['report_date']);out=args.output or args.input.parent/f'Báo cáo ngày {d.day}.{d.month}.{d.year} ({weekday(d).capitalize()}).docx'
    if out.exists():raise ValueError('Tệp đầu ra đã tồn tại; chọn đường dẫn khác để giữ bản trước')
    start=time.perf_counter();write_report(data,out,template);print(json.dumps({'output':str(out.resolve()),'seconds':round(time.perf_counter()-start,3),'visual_check':'not_performed'},ensure_ascii=False))
if __name__=='__main__':
    try:main()
    except (ValueError,KeyError,TypeError,OSError) as e:print(str(e),file=sys.stderr);sys.exit(2)

