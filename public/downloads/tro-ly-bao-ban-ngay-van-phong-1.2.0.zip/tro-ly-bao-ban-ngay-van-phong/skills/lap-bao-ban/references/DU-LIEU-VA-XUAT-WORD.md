# Dữ liệu và xuất Word
Chỉ dành cho trợ lý. Người dùng nhập văn bản/ảnh như bình thường, không phải nhập JSON.
Python 3 chuẩn, không thư viện ngoài. Tất cả đường dẫn tương đối với thư mục skill.
## Lệnh
- `python scripts/export_docx.py --preflight`: kiểm tra mẫu đúng và runtime chạy được.
- `python scripts/export_docx.py --init bao-ban.json`: tạo trạng thái ban đầu (ngày Việt Nam hiện tại), không ghi đè tệp có sẵn.
- `python scripts/export_docx.py --input bao-ban.json --check`: báo trường thiếu hoặc sai; mã lỗi 2.
- `python scripts/export_docx.py --input bao-ban.json --output "Báo cáo ngày d.m.yyyy (Thứ ...).docx"`: xuất theo mẫu.
Dùng runtime Python có sẵn, không tự cài dependencies. Output filename phải theo ngày báo cáo; ngày đã chốt giữ nguyên qua phiên.
## Cấu trúc JSON
- report_date: YYYY-MM-DD, ngày bắt đầu theo Asia/Ho_Chi_Minh. Ngày 01 bị chặn.
- security: mảng nội dung vụ việc đã tóm tắt theo cấu hình, đúng thứ tự; [] khi người dùng nói Không. Chưa nhập là null.
- ports: object với đúng tên Cát Lái, TCIT, TCTT, TCHP, HICT, TC189, TC128. Mỗi cảng gồm ships (số nguyên), cumulative_teu (nguyên TEU), ps và barge (số hoặc chuỗi thập phân dấu chấm; null hoặc "-" khi nguồn xác nhận không hoạt động), stock_teu (nguyên TEU). Không dùng dấu nghìn trong JSON. Thiếu NSGP thì để thiếu key, không dùng null để che dữ liệu chưa nhận.
- NSGP số 0 chỉ hợp lệ nếu ships=0 (PS) hoặc barge_trips=0 (sà lan); chuyển hiển thị "-". Nếu nguồn xác nhận không hoạt động thì nhập null. Tồn vượt sức chứa chỉ được xuất khi stock_confirmed=true sau khi người dùng xác nhận.
- cat_lai_activity: road_teu (nguyên), hours_per_cont (số/chuỗi dấu chấm).
- plan: null hoặc [] khi Không; nếu có, mảng hàng, mỗi hàng đúng 5 ô theo Giờ | Nội dung công việc | Địa điểm | Chủ trì | Tham gia. Ô có thể chuỗi rỗng nếu nguồn để trống.
- plan_merges: tùy chọn danh sách [r0,c0,r1,c1], chỉ số bắt đầu 0 trên hàng dữ liệu (không tính header). Chỉ gộp khi ảnh nguồn yêu cầu; ô bị gộp phải rỗng, nội dung chuyển vào ô đầu; không được gộp chồng nhau.
- notes: null/[] khi Không; nếu có, mảng các ý.
- commander: {name: tên trực BTL, title: chức danh}; không thêm Đ/c vào name.
- duties: key là nhãn in trong bảng: Trực xe, CTr, Cát Lái, KVMB, Trực TM, Hậu cần, TCHP, TCMT, Nội vụ, CNTT, Cái Mép, TCPC, Trực chỉ huy cơ quan, TTĐĐ, KVTNB, Xử lý sự cố kỹ thuật, Thạnh Mỹ Lợi, ICDST, Trực ban tác chiến, ICDLB. Value chỉ tên/ký hiệu giữ nguyên, không thêm đ/c. Dòng giao thông Cát Lái cố định Luật được chương trình điền.
- completed: mảng gồm security, plan, notes khi từng phần đã được nhận rõ (Không cũng phải đánh dấu). Phân biệt "chưa nhập" với "không có".
## Rich text
Mỗi ý security/notes và mỗi ô plan có thể là chuỗi hoặc mảng run: [{"text":"Nội dung","bold":true,"italic":false,"underline":false}]. Giữ nhấn mạnh theo nguồn/mẫu, không in đậm toàn bộ tên trực. Không tự thêm dữ liệu.
## Kiểm tra
Chương trình kiểm tra dữ liệu, số ngày, làm tròn half-up, thiếu vị trí trực và hash mẫu. Chỉ word/document.xml thay đổi; các phần DOCX khác giữ byte nguyên gốc. Kiểm tra hình thức bằng renderer là bước riêng, tùy công cụ môi trường. Không gọi dữ liệu kỹ thuật thử là dữ liệu thật.



## Mẫu chuẩn 1.2.0
Bộ xuất chỉ dùng assets/MAU-BAO-BAN-CHUAN.docx. Giữ nguyên các run của mẫu khi thay dữ liệu. Plan dùng hàng dữ liệu thứ nhất làm kiểu cơ sở 13 pt, rich runs mô tả nhấn mạnh theo dữ liệu nguồn. Notes có kiểu cơ sở nghiêng 13 pt, rich runs dùng cho chức danh/cụm cần đậm; không lấy nhấn mạnh gắn với tên minh họa để suy diễn tên mới. Tất cả tên/ngày/số trong mẫu chỉ minh họa.

